package app.jyu.fabric;

import app.jyu.common.Constants;
import app.jyu.common.PingPoint;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public final class FabricPayloads {
    static final class_9139<class_2540, PingC2S> PING_C2S_CODEC = class_9139.method_56438(PingC2S::write, PingC2S::read);
    static final class_9139<class_2540, RemovePingC2S> REMOVE_PING_C2S_CODEC = class_9139.method_56438(RemovePingC2S::write, RemovePingC2S::read);
    static final class_9139<class_2540, PingS2C> PING_S2C_CODEC = class_9139.method_56438(PingS2C::write, PingS2C::read);
    static final class_9139<class_2540, RemovePingS2C> REMOVE_PING_S2C_CODEC = class_9139.method_56438(RemovePingS2C::write, RemovePingS2C::read);

    private FabricPayloads() {
    }

    static void register() {
        PayloadTypeRegistry.playC2S().register(PingC2S.TYPE, PING_C2S_CODEC);
        PayloadTypeRegistry.playC2S().register(RemovePingC2S.TYPE, REMOVE_PING_C2S_CODEC);
        PayloadTypeRegistry.playS2C().register(PingS2C.TYPE, PING_S2C_CODEC);
        PayloadTypeRegistry.playS2C().register(RemovePingS2C.TYPE, REMOVE_PING_S2C_CODEC);
    }

    public record PingC2S(PingPoint point) implements class_8710 {
        public static final class_9154<PingC2S> TYPE = new class_9154<>(Constants.PING_PACKET);

        private void write(class_2540 buf) {
            point.write(buf);
        }

        private static PingC2S read(class_2540 buf) {
            return new PingC2S(PingPoint.read(buf));
        }

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }

    public record RemovePingC2S(PingPoint point) implements class_8710 {
        public static final class_9154<RemovePingC2S> TYPE = new class_9154<>(Constants.REMOVE_PING_PACKET);

        private void write(class_2540 buf) {
            point.write(buf);
        }

        private static RemovePingC2S read(class_2540 buf) {
            return new RemovePingC2S(PingPoint.read(buf));
        }

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }

    public record PingS2C(PingPoint point) implements class_8710 {
        public static final class_9154<PingS2C> TYPE = new class_9154<>(Constants.PING_PACKET);

        private void write(class_2540 buf) {
            point.write(buf);
        }

        private static PingS2C read(class_2540 buf) {
            return new PingS2C(PingPoint.read(buf));
        }

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }

    public record RemovePingS2C(PingPoint point) implements class_8710 {
        public static final class_9154<RemovePingS2C> TYPE = new class_9154<>(Constants.REMOVE_PING_PACKET);

        private void write(class_2540 buf) {
            point.write(buf);
        }

        private static RemovePingS2C read(class_2540 buf) {
            return new RemovePingS2C(PingPoint.read(buf));
        }

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }
}
