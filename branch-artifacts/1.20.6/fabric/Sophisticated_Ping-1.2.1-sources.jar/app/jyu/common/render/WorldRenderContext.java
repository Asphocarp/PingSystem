package app.jyu.common.render;

import net.minecraft.class_4184;
import net.minecraft.class_4587;
import org.joml.Matrix4f;

public final class WorldRenderContext {
    public final class_4587 poseStack;
    public final Matrix4f projectionMatrix;
    public final float tickDelta;
    public final class_4184 camera;

    private WorldRenderContext(class_4587 poseStack, Matrix4f projectionMatrix, float tickDelta, class_4184 camera) {
        this.poseStack = poseStack;
        this.projectionMatrix = projectionMatrix;
        this.tickDelta = tickDelta;
        this.camera = camera;
    }

    public static WorldRenderContext of(class_4587 poseStack, Matrix4f projectionMatrix, float tickDelta, class_4184 camera) {
        return new WorldRenderContext(poseStack, projectionMatrix, tickDelta, camera);
    }
}
