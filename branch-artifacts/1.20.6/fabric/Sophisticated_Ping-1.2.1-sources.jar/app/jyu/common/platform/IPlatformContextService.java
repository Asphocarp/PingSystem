package app.jyu.common.platform;

import java.nio.file.Path;
import java.util.ServiceLoader;
import net.minecraft.class_304;

public interface IPlatformContextService {
    IPlatformContextService INSTANCE = ServiceLoader.load(IPlatformContextService.class)
            .findFirst()
            .orElseThrow(() -> new IllegalStateException("No IPlatformContextService implementation found"));

    Path resolveConfigDir(String path);

    void registerKeyMapping(class_304 keyMapping);

    boolean isModLoaded(String modId);
}
