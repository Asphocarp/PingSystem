package app.jyu.common.platform;

import app.jyu.common.PingPoint;
import java.util.ServiceLoader;
import net.minecraft.class_3222;

public interface IPlatformNetworkService {
    IPlatformNetworkService INSTANCE = ServiceLoader.load(IPlatformNetworkService.class)
            .findFirst()
            .orElseThrow(() -> new IllegalStateException("No IPlatformNetworkService implementation found"));

    void sendPingToServer(PingPoint point);

    void sendRemovePingToServer(PingPoint point);

    void sendPingToClient(class_3222 player, PingPoint point);

    void sendRemovePingToClient(class_3222 player, PingPoint point);
}
