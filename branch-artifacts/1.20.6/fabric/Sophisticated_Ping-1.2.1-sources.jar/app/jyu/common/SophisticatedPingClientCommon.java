package app.jyu.common;

import app.jyu.common.config.ModConfig;
import app.jyu.common.platform.IPlatformClientEventService;
import app.jyu.common.platform.IPlatformContextService;
import app.jyu.common.platform.IPlatformNetworkService;
import app.jyu.common.render.RenderHandler;
import org.lwjgl.glfw.GLFW;

import java.util.Objects;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1675;
import net.minecraft.class_2248;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_746;

public final class SophisticatedPingClientCommon {
    public static final double MAX_REACH = 512.0D;
    public static final class_304 PING_KEY = new class_304(
            "key.sophisticated_ping.ping",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_C,
            "category.sophisticated_ping.sophisticated_ping"
    );

    private SophisticatedPingClientCommon() {
    }

    public static void init() {
        ModConfig.load();
        IPlatformContextService.INSTANCE.registerKeyMapping(PING_KEY);
        IPlatformClientEventService.INSTANCE.registerEndClientTick(SophisticatedPingClientCommon::onClientTick);
        IPlatformClientEventService.INSTANCE.registerRenderWorld(RenderHandler.getInstance()::onRenderWorld);
        IPlatformClientEventService.INSTANCE.registerRenderGui(RenderHandler.getInstance()::onRenderGui);
    }

    public static void receivePing(PingPoint point) {
        if (point == null || point.isCorrupt()) {
            Constants.LOGGER.warn("Ignoring corrupt client ping packet");
            return;
        }
        RenderHandler.getInstance().addPing(point);
    }

    public static void receiveRemovePing(PingPoint point) {
        if (point == null || point.isCorrupt()) {
            Constants.LOGGER.warn("Ignoring corrupt client remove ping packet");
            return;
        }
        RenderHandler.getInstance().removePing(point);
    }

    private static void onClientTick() {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null || client.field_1724 == null) {
            return;
        }

        while (PING_KEY.method_1436()) {
            handlePingAction(client, client.field_1724, ModConfig.includeFluids);
        }
    }

    private static void handlePingAction(class_310 client, class_746 player, boolean includeFluids) {
        class_1297 cameraEntity = client.field_1719;
        if (client.field_1687 == null || cameraEntity == null) {
            return;
        }

        class_239 hit = raycast(cameraEntity, MAX_REACH, client.method_1488(), includeFluids);
        if (hit == null) {
            return;
        }

        PingPoint pingToSend = null;
        switch (hit.method_17783()) {
            case field_1333 -> player.method_7353(class_2561.method_43470("Too far"), true);
            case field_1332 -> {
                class_3965 blockHit = (class_3965) hit;
                class_2680 blockState = client.field_1687.method_8320(blockHit.method_17777());
                class_2248 block = blockState.method_26204();
                player.method_7353(block.method_9518(), true);
                pingToSend = PingPoint.location(hit.method_17784(), player.method_7334().getName(), ModConfig.highlightColor, ModConfig.soundIndex);
            }
            case field_1331 -> {
                class_3966 entityHit = (class_3966) hit;
                class_1297 entity = entityHit.method_17782();
                player.method_7353(entity.method_5477(), true);
                pingToSend = PingPoint.entity(
                        entity.method_5829().method_1005(),
                        player.method_7334().getName(),
                        ModConfig.highlightColor,
                        ModConfig.soundIndex,
                        entity.method_5667()
                );
            }
        }

        if (pingToSend != null) {
            processPing(pingToSend);
        }
    }

    private static void processPing(PingPoint point) {
        RenderHandler renderer = RenderHandler.getInstance();
        if (renderer.isOnPing()) {
            PingPoint existing = renderer.getOnPing();
            renderer.removeOnPing();
            IPlatformNetworkService.INSTANCE.sendRemovePingToServer(existing);
            renderer.resetOnPing();
            return;
        }

        renderer.addPing(point);
        IPlatformNetworkService.INSTANCE.sendPingToServer(point);
    }

    private static class_239 raycast(class_1297 cameraEntity, double maxDistance, float tickDelta, boolean includeFluids) {
        class_243 cameraPos = cameraEntity.method_5836(tickDelta);
        class_243 rotationVec = cameraEntity.method_5828(tickDelta);
        class_243 endVec = cameraPos.method_1019(rotationVec.method_1021(maxDistance));
        class_238 searchBox = cameraEntity.method_5829().method_18804(rotationVec.method_1021(maxDistance)).method_1014(1.0D);

        class_3965 blockHitResult = cameraEntity.method_37908().method_17742(new class_3959(
                cameraPos,
                endVec,
                class_3959.class_3960.field_17559,
                includeFluids ? class_3959.class_242.field_1347 : class_3959.class_242.field_1348,
                cameraEntity
        ));

        double currentMaxDistSq = endVec.method_1025(cameraPos);
        if (blockHitResult.method_17783() != class_239.class_240.field_1333) {
            currentMaxDistSq = blockHitResult.method_17784().method_1025(cameraPos);
        }

        Predicate<class_1297> entityPredicate = entity -> !entity.method_7325() && entity.method_5863();
        class_3966 entityHitResult = class_1675.method_18075(
                cameraEntity,
                cameraPos,
                endVec,
                searchBox,
                entityPredicate,
                currentMaxDistSq
        );

        if (entityHitResult == null) {
            return blockHitResult;
        }

        double entityDistSq = entityHitResult.method_17784().method_1025(cameraPos);
        if (entityDistSq < currentMaxDistSq || blockHitResult.method_17783() == class_239.class_240.field_1333) {
            return entityHitResult;
        }
        return Objects.requireNonNull(blockHitResult);
    }
}
