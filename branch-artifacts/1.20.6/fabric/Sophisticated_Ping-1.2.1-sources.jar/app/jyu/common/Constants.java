package app.jyu.common;

import net.minecraft.class_2960;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Constants {
    public static final String MOD_ID = "sophisticated_ping";
    public static final String FORGE_MOD_ID = "sophisticated_ping";
    public static final String MOD_NAME = "Sophisticated Ping";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final class_2960 PING_PACKET = id("ping");
    public static final class_2960 REMOVE_PING_PACKET = id("remove_ping");

    private Constants() {
    }

    public static class_2960 id(String path) {
        return new class_2960(MOD_ID, path);
    }
}
