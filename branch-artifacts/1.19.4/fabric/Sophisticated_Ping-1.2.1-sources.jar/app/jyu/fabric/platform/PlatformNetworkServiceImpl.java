package app.jyu.fabric.platform;

import app.jyu.common.Constants;
import app.jyu.common.PingPoint;
import app.jyu.common.platform.IPlatformNetworkService;
import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_3222;

public final class PlatformNetworkServiceImpl implements IPlatformNetworkService {
    @Override
    public void sendPingToServer(PingPoint point) {
        sendToServer(Constants.PING_PACKET, point);
    }

    @Override
    public void sendRemovePingToServer(PingPoint point) {
        sendToServer(Constants.REMOVE_PING_PACKET, point);
    }

    @Override
    public void sendPingToClient(class_3222 player, PingPoint point) {
        sendToClient(player, Constants.PING_PACKET, point);
    }

    @Override
    public void sendRemovePingToClient(class_3222 player, PingPoint point) {
        sendToClient(player, Constants.REMOVE_PING_PACKET, point);
    }

    private static void sendToServer(net.minecraft.class_2960 id, PingPoint point) {
        if (!ClientPlayNetworking.canSend(id)) {
            return;
        }
        class_2540 buf = new class_2540(Unpooled.buffer());
        point.write(buf);
        ClientPlayNetworking.send(id, buf);
    }

    private static void sendToClient(class_3222 player, net.minecraft.class_2960 id, PingPoint point) {
        if (!ServerPlayNetworking.canSend(player, id)) {
            return;
        }
        class_2540 buf = new class_2540(Unpooled.buffer());
        point.write(buf);
        ServerPlayNetworking.send(player, id, buf);
    }
}
