package app.jyu.common.render;

import app.jyu.common.Constants;
import app.jyu.common.PingPoint;
import app.jyu.common.SophisticatedPingClientCommon;
import app.jyu.common.config.ModConfig;
import com.mojang.blaze3d.systems.RenderSystem;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_757;

public final class RenderHandler {
    private static final RenderHandler INSTANCE = new RenderHandler();
    private static final class_2960 PING_BASIC = Constants.id("textures/ping/ping_basic.png");

    private final Map<String, CopyOnWriteArrayList<PingPoint>> pings = new HashMap<>();
    private final Map<UUID, Vector4f> pingClipCoordinates = new HashMap<>();
    private PingPoint onPing;

    private RenderHandler() {
    }

    public static RenderHandler getInstance() {
        return INSTANCE;
    }

    public void addPing(PingPoint point) {
        CopyOnWriteArrayList<PingPoint> pingList = pings.computeIfAbsent(point.owner(), ignored -> new CopyOnWriteArrayList<>());
        if (pingList.size() >= ModConfig.pingNumEach) {
            pingList.subList(0, pingList.size() - ModConfig.pingNumEach + 1).clear();
        }
        pingList.add(point);
    }

    public PingPoint getOnPing() {
        return onPing;
    }

    public boolean isOnPing() {
        return onPing != null;
    }

    public void removeOnPing() {
        if (onPing == null) {
            return;
        }
        removePing(onPing);
    }

    public void removePing(PingPoint point) {
        CopyOnWriteArrayList<PingPoint> pingList = pings.get(point.owner());
        if (pingList == null) {
            return;
        }
        pingList.removeIf(candidate -> candidate.id().equals(point.id()));
        pingClipCoordinates.remove(point.id());
    }

    public void resetOnPing() {
        onPing = null;
    }

    public void onRenderWorld(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null || client.field_1724 == null || client.field_1690.field_1842) {
            return;
        }
        removeExpiredPings();
        calculatePingScreenCoordinates(context);
    }

    public void onRenderGui(class_4587 poseStack, float tickDelta) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1690.field_1842) {
            return;
        }

        boolean foundOnPing = false;
        int width = client.method_22683().method_4486();
        int height = client.method_22683().method_4502();
        double halfWidth = width / 2.0;
        double halfHeight = height / 2.0;

        for (CopyOnWriteArrayList<PingPoint> pingList : pings.values()) {
            for (PingPoint ping : pingList) {
                Vector4f clipPos = pingClipCoordinates.get(ping.id());
                if (clipPos == null || clipPos.w() <= 0) {
                    continue;
                }

                float ndcX = clipPos.x() / clipPos.w();
                float ndcY = clipPos.y() / clipPos.w();
                double screenX = halfWidth + ndcX * halfWidth;
                double screenY = halfHeight - ndcY * halfHeight;
                double margin = Math.max(8.0, ModConfig.iconSize * 4.0);
                screenX = class_3532.method_15350(screenX, margin, width - margin);
                screenY = class_3532.method_15350(screenY, margin, height - margin);

                renderIcon(poseStack, screenX, screenY);

                if (!foundOnPing) {
                    double dx = screenX - halfWidth;
                    double dy = screenY - halfHeight;
                    double threshold = Math.min(width, height) / 25.0;
                    if (dx * dx + dy * dy <= threshold * threshold) {
                        renderInfo(poseStack, (int) halfWidth + 5, (int) halfHeight + 5, ping);
                        onPing = ping;
                        foundOnPing = true;
                    }
                }
            }
        }

        if (!foundOnPing) {
            onPing = null;
        }
    }

    private void removeExpiredPings() {
        for (CopyOnWriteArrayList<PingPoint> pingList : pings.values()) {
            pingList.removeIf(ping -> {
                boolean remove = ping.shouldVanish(ModConfig.secondsToVanish);
                if (remove) {
                    pingClipCoordinates.remove(ping.id());
                }
                return remove;
            });
        }
    }

    private void calculatePingScreenCoordinates(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) {
            return;
        }

        pingClipCoordinates.clear();
        class_243 cameraPos = context.camera.method_19326();
        Matrix4f projectionMatrix = new Matrix4f(context.projectionMatrix);

        for (CopyOnWriteArrayList<PingPoint> pingList : pings.values()) {
            for (PingPoint ping : pingList) {
                class_243 targetPos = effectiveTargetPos(client, ping, context.tickDelta);
                context.poseStack.method_22903();
                context.poseStack.method_22904(targetPos.field_1352 - cameraPos.field_1352, targetPos.field_1351 - cameraPos.field_1351, targetPos.field_1350 - cameraPos.field_1350);
                Matrix4f modelView = context.poseStack.method_23760().method_23761();
                Vector4f clipPos = new Matrix4f(projectionMatrix).mul(modelView).transform(new Vector4f(0, 0, 0, 1));
                pingClipCoordinates.put(ping.id(), clipPos);
                context.poseStack.method_22909();
            }
        }
    }

    private class_243 effectiveTargetPos(class_310 client, PingPoint ping, float tickDelta) {
        if (ping.type() != PingPoint.PingType.ENTITY || ping.entityUuid() == null || client.field_1687 == null) {
            return ping.pos();
        }

        for (class_1297 entity : client.field_1687.method_18112()) {
            if (entity.method_5667().equals(ping.entityUuid())) {
                class_243 feet = entity.method_30950(tickDelta);
                return feet.method_1031(0, entity.method_17682() / 2.0, 0);
            }
        }
        return ping.pos();
    }

    private void renderIcon(class_4587 poseStack, double centerX, double centerY) {
        int size = Math.max(8, Math.round(8 * ModConfig.iconSize));
        int x = (int) Math.round(centerX - size / 2.0);
        int y = (int) Math.round(centerY - size / 2.0);
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderTexture(0, PING_BASIC);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        class_332.method_25291(poseStack, x, y, 0, 0, 0, size, size, size, size);
    }

    private void renderInfo(class_4587 poseStack, int x, int y, PingPoint ping) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            return;
        }

        double distance = client.field_1724.method_19538().method_1022(ping.pos());
        client.field_1772.method_1720(poseStack, "%.0f m".formatted(distance), x, y, ModConfig.infoColor);
        y += client.field_1772.field_2000 + 2;

        if (!ping.owner().equals(client.field_1724.method_7334().getName())) {
            client.field_1772.method_1720(poseStack, ping.owner(), x, y, ModConfig.infoColor);
            y += client.field_1772.field_2000 + 2;
        }

        client.field_1772.method_1720(poseStack, "Cancel (" + humanReadableHotkey() + ")", x, y, 0xFFFFFFFF);
    }

    private static String humanReadableHotkey() {
        String key = SophisticatedPingClientCommon.PING_KEY.method_16007().getString();
        if (key == null || key.isBlank()) {
            return "C";
        }
        return key.toUpperCase();
    }
}
