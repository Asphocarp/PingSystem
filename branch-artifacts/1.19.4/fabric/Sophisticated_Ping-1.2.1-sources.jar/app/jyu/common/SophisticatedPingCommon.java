package app.jyu.common;

import app.jyu.common.platform.IPlatformNetworkService;
import app.jyu.common.platform.IPlatformServerEventService;
import net.minecraft.class_1297;
import net.minecraft.class_2378;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class SophisticatedPingCommon {
    public static final long GLOW_DURATION_MS = 5000;
    private static final Map<UUID, Long> GLOWING_ENTITIES = new ConcurrentHashMap<>();

    private static final List<String> CUSTOM_SOUNDS = List.of(
            "ping_location",
            "ping_item",
            "ping_enemy",
            "mozambique_lifeline"
    );

    private static final List<class_3414> SOUND_EVENTS = new ArrayList<>();

    private SophisticatedPingCommon() {
    }

    public static void init() {
        Constants.LOGGER.info("Make MC Apex Again!");
        registerSounds();
        IPlatformServerEventService.INSTANCE.registerEndServerTick(SophisticatedPingCommon::onEndServerTick);
    }

    public static int soundCount() {
        return SOUND_EVENTS.size();
    }

    public static void onPingPacket(MinecraftServer server, class_3222 sender, PingPoint point) {
        if (point == null || point.isCorrupt()) {
            Constants.LOGGER.warn("Ignoring corrupt ping packet from {}", sender.method_7334().getName());
            return;
        }

        handleGlow(server, sender, point);
        multicastPing(sender, point);
    }

    public static void onRemovePingPacket(class_3222 sender, PingPoint point) {
        if (point == null || point.isCorrupt()) {
            Constants.LOGGER.warn("Ignoring corrupt remove ping packet from {}", sender.method_7334().getName());
            return;
        }

        for (class_3222 teammate : sender.method_14220().method_18456()) {
            if (teammate.method_5667().equals(sender.method_5667())) {
                continue;
            }
            IPlatformNetworkService.INSTANCE.sendRemovePingToClient(teammate, point);
        }
    }

    private static void multicastPing(class_3222 sender, PingPoint point) {
        class_3414 sound = soundIdxToEvent(point.sound());
        for (class_3222 teammate : sender.method_14220().method_18456()) {
            teammate.method_14220().method_8396(
                    null,
                    teammate.method_24515(),
                    sound,
                    class_3419.field_15245,
                    1f,
                    1f
            );

            if (teammate.method_5667().equals(sender.method_5667())) {
                continue;
            }

            IPlatformNetworkService.INSTANCE.sendPingToClient(teammate, point);
            Constants.LOGGER.debug("{} sent ping to {}", sender.method_7334().getName(), teammate.method_7334().getName());
        }
    }

    private static void handleGlow(MinecraftServer server, class_3222 sender, PingPoint point) {
        if (point.type() != PingPoint.PingType.ENTITY || point.entityUuid() == null) {
            return;
        }

        UUID entityUuid = point.entityUuid();
        long glowEndTime = System.currentTimeMillis() + GLOW_DURATION_MS;
        server.execute(() -> {
            class_1297 entity = findEntity(server, sender.method_14220(), entityUuid);
            if (entity == null) {
                Constants.LOGGER.warn("Received highlight request for {}, but entity was not found", entityUuid);
                return;
            }

            entity.method_5834(true);
            GLOWING_ENTITIES.put(entityUuid, glowEndTime);
        });
    }

    private static class_1297 findEntity(MinecraftServer server, class_3218 preferredLevel, UUID entityUuid) {
        class_1297 entity = preferredLevel.method_14190(entityUuid);
        if (entity != null) {
            return entity;
        }

        for (class_3218 level : server.method_3738()) {
            if (level == preferredLevel) {
                continue;
            }
            entity = level.method_14190(entityUuid);
            if (entity != null) {
                return entity;
            }
        }
        return null;
    }

    private static void onEndServerTick(MinecraftServer server) {
        long now = System.currentTimeMillis();
        GLOWING_ENTITIES.entrySet().removeIf(entry -> {
            if (now < entry.getValue()) {
                return false;
            }

            server.execute(() -> {
                for (class_3218 level : server.method_3738()) {
                    class_1297 entity = level.method_14190(entry.getKey());
                    if (entity != null && entity.method_5851()) {
                        entity.method_5834(false);
                    }
                }
            });
            return true;
        });
    }

    private static class_3414 soundIdxToEvent(byte soundIdx) {
        if (soundIdx < 0 || soundIdx >= SOUND_EVENTS.size()) {
            return SOUND_EVENTS.get(0);
        }
        return SOUND_EVENTS.get(soundIdx);
    }

    private static void registerSounds() {
        if (!SOUND_EVENTS.isEmpty()) {
            return;
        }

        for (String soundName : CUSTOM_SOUNDS) {
            var soundId = Constants.id(soundName);
            class_3414 soundEvent = class_3414.method_47908(soundId);
            class_2378.method_10230(class_7923.field_41172, soundId, soundEvent);
            SOUND_EVENTS.add(soundEvent);
        }
        SOUND_EVENTS.add(class_3417.field_14542);
    }
}
