package app.jyu.common;

import java.util.UUID;
import net.minecraft.class_243;
import net.minecraft.class_2540;

public record PingPoint(
        UUID id,
        class_243 pos,
        String owner,
        int color,
        byte sound,
        long createdAtMillis,
        PingType type,
        UUID entityUuid
) {
    public enum PingType {
        LOCATION,
        ENTITY
    }

    public static PingPoint location(class_243 pos, String owner, int color, byte sound) {
        return new PingPoint(UUID.randomUUID(), pos, owner, color, sound, System.currentTimeMillis(), PingType.LOCATION, null);
    }

    public static PingPoint entity(class_243 pos, String owner, int color, byte sound, UUID entityUuid) {
        return new PingPoint(UUID.randomUUID(), pos, owner, color, sound, System.currentTimeMillis(), PingType.ENTITY, entityUuid);
    }

    public boolean shouldVanish(long secondsToVanish) {
        if (secondsToVanish == 0) {
            return false;
        }
        return System.currentTimeMillis() - createdAtMillis > secondsToVanish * 1000L;
    }

    public boolean isCorrupt() {
        if (id == null || pos == null || owner == null || type == null) {
            return true;
        }
        return type == PingType.ENTITY && entityUuid == null;
    }

    public void write(class_2540 buf) {
        buf.method_10797(id);
        buf.writeDouble(pos.field_1352);
        buf.writeDouble(pos.field_1351);
        buf.writeDouble(pos.field_1350);
        buf.method_10788(owner, 64);
        buf.writeInt(color);
        buf.writeByte(sound);
        buf.writeLong(createdAtMillis);
        buf.method_10817(type);
        buf.writeBoolean(entityUuid != null);
        if (entityUuid != null) {
            buf.method_10797(entityUuid);
        }
    }

    public static PingPoint read(class_2540 buf) {
        try {
            UUID id = buf.method_10790();
            class_243 pos = new class_243(buf.readDouble(), buf.readDouble(), buf.readDouble());
            String owner = buf.method_10800(64);
            int color = buf.readInt();
            byte sound = buf.readByte();
            long createdAtMillis = buf.readLong();
            PingType type = buf.method_10818(PingType.class);
            UUID entityUuid = buf.readBoolean() ? buf.method_10790() : null;
            PingPoint point = new PingPoint(id, pos, owner, color, sound, createdAtMillis, type, entityUuid);
            return point.isCorrupt() ? null : point;
        } catch (RuntimeException e) {
            Constants.LOGGER.warn("Failed to read ping packet", e);
            return null;
        } finally {
            if (buf.readableBytes() > 0) {
                buf.readerIndex(buf.readerIndex() + buf.readableBytes());
            }
        }
    }
}
